import express from "express";
import cors from 'cors';
import apiRouter from "./routes/apiRouter.js";

const app = express();

app.use("/api", apiRouter);

app.use(cors());

export default app;
